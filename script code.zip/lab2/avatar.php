<?php 
 $avt = $_GET["nickname"];
 if($avt == "1")
 echo "Mr. avatar1";
 else if($avt == "2")
 echo "Mrs. avatar2";
 else if($avt == "3")
 echo "Mr. avatar3";
 else if($avt == "4")
 echo "Mrs. avatar4";
 else if($avt == "5")
 echo "Mr. avatar5";
 else if($avt == "6") 
 echo "Mrs. avatar6";
 // echo avatar name, e.g., nickname no.=1, avatar name = �Mr. avatar1�
?>