<?php 
$name = $_GET["name"];
// connect to the database
$conn = mysqli_connect("localhost", "root", "", "registerdb2");
    $conn->query("SET NAMES UTF8");
$sql = "SELECT * FROM register WHERE firstname LIKE '%".$name."%' ";
// Add Code Here �
$rs=$conn->query($sql);
while($row = $rs->fetch_assoc()){
    echo '<option value='.$row['firstname'].'>';
}
$conn->close();
?>
